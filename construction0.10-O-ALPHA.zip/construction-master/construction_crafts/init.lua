-- Code License: CC BY-SA
-- (https://creativecommons.org/licenses/by-sa/3.0/legalcode)

-- Early Crafts
minetest.register_craft({
	output = 'construction_wood:wall_wood 3',
	recipe = {
		{'default:wood', 'default:wood', 'default:wood'},
		{'default:wood', 'default:wood', 'default:wood'},
		{'default:wood', 'default:wood', 'default:wood'},
	}
})

minetest.register_craft({
	output = 'construction_wood:wall_doorway_wood 3',
	recipe = {
		{'default:wood', 'default:wood', 'default:wood'},
		{'default:wood', '', 'default:wood'},
		{'default:wood', '', 'default:wood'},
	}
})

minetest.register_craft({
	output = 'construction_wood:beam_wood',
	recipe = {
		{'', 'default:stick', ''},
		{'default:tree', 'default:tree', 'default:tree'},
		{'', 'default:stick', ''},
	}
})

minetest.register_craft({
	output = 'construction_wood:beam_wood_vertical',
	recipe = {
		{'', 'default:tree', ''},
		{'default:stick', 'default:tree', 'default:stick'},
		{'', 'default:tree', ''},
	}
})

minetest.register_craft({
	output = 'construction_wood:beam_wood_vertical',
	recipe = {
		{'', '', ''},
		{'', 'construction_wood:beam_wood', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_wood:beam_wood',
	recipe = {
		{'', '', ''},
		{'', 'construction_wood:beam_wood_vertical', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_wood:foundation',
	recipe = {
		{'default:cobble', 'default:cobble', 'default:cobble'},
		{'default:cobble', 'default:cobble', 'default:cobble'},
		{'default:cobble', 'default:cobble', 'default:cobble'},
	}
})

minetest.register_craft({
	output = 'construction_wood:foundation_thin 3',
	recipe = {
		{'', '', ''},
		{'', 'construction_wood:foundation', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_wood:foundation',
	recipe = {
		{'', '', ''},
		{'construction_wood:foundation_thin', 'construction_wood:foundation_thin', 'construction_wood:foundation_thin'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'default:cobble 3',
	recipe = {
		{'', '', ''},
		{'', 'construction_wood:foundation_thin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_wood:window_closed_wood',
	recipe = {
		{'', '', ''},
		{'', 'construction_wood:wall_wood', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_wood:door_closed_wood',
	recipe = {
		{'', '', ''},
		{'', 'doors:door_wood', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_wood:roof_wood 18',
	recipe = {
		{'', '', ''},
		{'', 'default:wood', 'default:stick'},
		{'', '', ''},
	}
})

-- Mid Crafts


minetest.register_craft({
	output = 'construction_tin:wall_tin',
	recipe = {
		{'construction_tin:tin_plate', 'construction_tin:tin_plate', 'construction_tin:tin_plate'},
		{'construction_tin:tin_plate', 'construction_tin:tin_plate', 'construction_tin:tin_plate'},
		{'construction_tin:tin_plate', 'construction_tin:tin_plate', 'construction_tin:tin_plate'},
	}
})

minetest.register_craft({
	output = 'construction_tin:wall_doorway_tin',
	recipe = {
		{'construction_tin:tin_plate', 'construction_tin:tin_plate', 'construction_tin:tin_plate'},
		{'construction_tin:tin_plate', '', 'construction_tin:tin_plate'},
		{'construction_tin:tin_plate', '', 'construction_tin:tin_plate'},
	}
})

minetest.register_craft({
	output = 'construction_tin:beam_tin',
	recipe = {
		{'', 'construction_tin:tin_plate', ''},
		{'default:tin_ingot', 'default:tin_ingot', 'default:tin_ingot'},
		{'', 'construction_tin:tin_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:beam_tin_vertical',
	recipe = {
		{'', 'default:tin_ingot', ''},
		{'construction_tin:tin_plate', 'default:tin_ingot', 'construction_tin:tin_plate'},
		{'', 'default:tin_ingot', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:beam_tin_vertical',
	recipe = {
		{'', '', ''},
		{'', 'construction_tin:beam_tin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:beam_tin',
	recipe = {
		{'', '', ''},
		{'', 'construction_tin:beam_tin_vertical', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:foundation_tin',
	recipe = {
		{'construction_tin:tin_plate', 'construction_tin:tin_plate', 'construction:tin_plate'},
		{'construction_tin:tin_plate', 'default:tinblock', 'construction_tin:tin_plate'},
		{'construction_tin:tin_plate', 'construction_tin:tin_plate', 'construction_tin:tin_plate'},
	}
})

minetest.register_craft({
	output = 'construction_tin:foundation_thin_tin 3',
	recipe = {
		{'', '', ''},
		{'', 'construction_tin:foundation_tin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:foundation_thin_tin 2',
	recipe = {
		{'', 'construction_tin:tin_plate', ''},
		{'', 'default:tinblock', ''},
		{'', 'construction_tin:tin_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:foundation_tin',
	recipe = {
		{'', '', ''},
		{'construction_tin:foundation_thin_tin', 'construction_tin:foundation_thin_tin', 'construction_tin:foundation_thin_tin'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:tin_plate 15',
	recipe = {
		{'', '', ''},
		{'', 'construction_tin:foundation_thin_tin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:tin_plate 9',
	recipe = {
		{'', '', ''},
		{'default:tin_ingot', 'default:tin_ingot', 'default:tin_ingot'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:window_closed_tin',
	recipe = {
		{'', '', ''},
		{'', 'construction_tin:wall_tin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:door_closed_tin',
	recipe = {
		{'', '', ''},
		{'', 'construction:tin_plate', ''},
		{'', 'construction:tin_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:mech_door_closed_tin',
	recipe = {
		{'', 'construction:wall_doorway_tin', ''},
		{'', 'construction:tin_plate', ''},
		{'', 'construction:tin_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction_tin:roof_tin 18',
	recipe = {
		{'', '', ''},
		{'', 'default:tinblock', 'default:stick'},
		{'', '', ''},
	}
})

--Steel

minetest.register_craft({
	output = 'construction_steel:wall_steel',
	recipe = {
		{'construction_steel:steel_plate', 'construction_steel:steel_plate', 'construction_steel:steel_plate'},
		{'construction_steel:steel_plate', 'construction_steel:steel_plate', 'construction_steel:steel_plate'},
		{'construction_steel:steel_plate', 'construction_steel:steel_plate', 'construction_steel:steel_plate'},
	}
})

minetest.register_craft({
	output = 'construction_steel:wall_doorway_steel',
	recipe = {
		{'construction_steel:steel_plate', 'construction_steel:steel_plate', 'construction_steel:steel_plate'},
		{'construction_steel:steel_plate', '', 'construction_steel:steel_plate'},
		{'construction_steel:steel_plate', '', 'construction_steel:steel_plate'},
	}
})

minetest.register_craft({
	output = 'construction_steel:beam_steel',
	recipe = {
		{'', 'construction_steel:steel_plate', ''},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'', 'construction_steel:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:beam_steel_vertical',
	recipe = {
		{'', 'default:steel_ingot', ''},
		{'construction_steel:steel_plate', 'default:steel_ingot', 'construction_steel:steel_plate'},
		{'', 'default:steel_ingot', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:beam_steel_vertical',
	recipe = {
		{'', '', ''},
		{'', 'construction_steel:beam_steel', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:beam_steel',
	recipe = {
		{'', '', ''},
		{'', 'construction_steel:beam_steel_vertical', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:foundation_steel',
	recipe = {
		{'construction_steel:steel_plate', 'construction_steel:steel_plate', 'construction_steel:steel_plate'},
		{'construction_steel:steel_plate', 'default:steelblock', 'construction_steel:steel_plate'},
		{'construction_steel:steel_plate', 'construction_steel:steel_plate', 'construction_steel:steel_plate'},
	}
})

minetest.register_craft({
	output = 'construction_steel:foundation_thin_steel 3',
	recipe = {
		{'', '', ''},
		{'', 'construction_steel:foundation_steel', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:foundation_thin_steel 2',
	recipe = {
		{'', 'construction_steel:steel_plate', ''},
		{'', 'default:steelblock', ''},
		{'', 'construction_steel:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:foundation_steel',
	recipe = {
		{'', '', ''},
		{'construction_steel:foundation_thin_steel', 'construction_steel:foundation_thin_steel', 'construction_steel:foundation_thin_steel'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:steel_plate 15',
	recipe = {
		{'', '', ''},
		{'', 'construction_steel:foundation_thin_steel', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:steel_plate 9',
	recipe = {
		{'', '', ''},
		{'default_steel:steel_ingot', 'default_steel:steel_ingot', 'default_steel:steel_ingot'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:window_closed_steel',
	recipe = {
		{'', '', ''},
		{'', 'construction_steel:wall_steel', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:door_closed_steel',
	recipe = {
		{'', '', ''},
		{'', 'construction_steel:steel_plate', ''},
		{'', 'construction_steel:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:mech_door_closed_steel',
	recipe = {
		{'', 'construction_steel:wall_doorway_steel', ''},
		{'', 'construction_steel:steel_plate', ''},
		{'', 'construction_steel:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction:window_steel_large',
	recipe = {
		{'construction_steel:steel_plate', 'construction_steel:steel_plate', 'construction_steel:steel_plate'},
		{'construction_steel:steel_plate', '', 'construction_steel:steel_plate'},
		{'construction_steel:steel_plate', 'construction_steel:steel_plate', 'construction_steel:steel_plate'},
	}
})

minetest.register_craft({
	output = 'construction_steel:glass_large 2',
	recipe = {
		{'', 'construction_steel:steel_plate', ''},
		{'construction_steel:steel_plate', 'default:glass', 'construction_steel:steel_plate'},
		{'', 'construction_steel:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction_steel:roof_steel 18',
	recipe = {
		{'', '', ''},
		{'', 'default_steel:steelblock', 'default_steel:stick'},
		{'', '', ''},
	}
})


