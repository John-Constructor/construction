-- Code License: CC BY-SA
-- (https://creativecommons.org/licenses/by-sa/3.0/legalcode)

minetest.register_node("construction_wood:wall_wood", {
	description = "Wooden Wall",
	inventory_image = "construction_wallwood.png",
	wield_image = "construction_wallwood.png",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
		}
	}
})

minetest.register_node("construction_wood:window_closed_wood", {
	description = "Wooden Window",
	inventory_image = "construction_windowwood.png",
	wield_image = "construction_windowwood.png",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 0.5, -0.0625, 0, 1.5, 0.0625}, -- NodeBox7
			{0, 0.5, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_wood:window_open_wood", param2 = node.param2})
                end,
})

minetest.register_node("construction_wood:window_open_wood", {
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	drop = "construction_wood:window_closed_wood",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5625, 0.5, -0.5, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.5, 0.5625, 1.5, 0.0625}, -- NodeBox9
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_wood:window_closed_wood", param2 = node.param2})
                end,
})

minetest.register_node("construction_wood:wall_doorway_wood", {
	description = "Wooden Doorway",
	inventory_image = "construction_doorwaywood.png",
	wield_image = "construction_doorwaywood.png",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox3
			{-1.5, 1.5, -0.125, 1.5, 2.3125, 0.125}, -- NodeBox4
			{-1.5, -0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
		}
	}
})

minetest.register_node("construction_wood:door_closed_wood", {
	description = "Wooden Door",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -1.5, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_wood:door_open_wood", param2 = node.param2})
                end,
})

minetest.register_node("construction_wood:door_open_wood", {
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	drop = "construction_wood:door_closed_wood",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{0.375, -1.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_wood:door_closed_wood", param2 = node.param2})
                end,
})

minetest.register_node("construction_wood:beam_wood", {
	description = "Horizontal Wooden Beam",
	inventory_image = "construction_beamwood.png",
	wield_image = "construction_beamwood.png",
	tiles = {
		"default_tree.png",
		"default_tree.png",
		"default_tree.png^[transformFXR90",
		"default_tree.png^[transformFXR90",
		"default_tree_top.png",
		"default_tree_top.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -2.5, 0.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_wood:beam_wood_vertical", {
	description = "Vertical Wooden Beam",
	inventory_image = "construction_beamwood.png",
	wield_image = "construction_beamwood.png",
	tiles = {
		"default_tree_top.png",
		"default_tree_top.png",
		"default_tree.png",
		"default_tree.png",
		"default_tree.png",
		"default_tree.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 2.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_wood:foundation", {
	description = "Standard Foundation",
	inventory_image = "construction_foundationcobble.png",
	wield_image = "construction_foundationcobble.png",
	tiles = {
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -1.5, 1.5, 0.5, 1.5}, -- NodeBox2
		}
	}
})

minetest.register_node("construction_wood:foundation_thin", {
	description = "Adjustment Foundation",
	inventory_image = "construction_adfoundationcobble.png",
	wield_image = "construction_adfoundationcobble.png",
	tiles = {
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_wood:roof_wood", {
	description = "Wooden Roof",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.4375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.125, 0.375, -0.5, 0.125, 0.4375, 0.5}, -- NodeBox2
			{-0.5, 0.375, -0.125, 0.5, 0.4375, 0.125}, -- NodeBox3
		}
	}
})
