-- Code License: CC BY-SA
-- (https://creativecommons.org/licenses/by-sa/3.0/legalcode)

minetest.register_node("construction_steel:wall_steel", {
	description = "Steel Wall",
	inventory_image = "construction_wallsteel.png",
	wield_image = "construction_wallsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
		}
	}
})

minetest.register_node("construction_steel:window_closed_steel", {
	description = "Steel Window",
	inventory_image = "construction_windowsteel.png",
	wield_image = "construction_windowsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 0.5, -0.0625, 0, 1.5, 0.0625}, -- NodeBox7
			{0, 0.5, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:window_open_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction_steel:window_open_steel", {
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	drop = "construction:window_closed_steel",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5625, 0.5, -0.5, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.5, 0.5625, 1.5, 0.0625}, -- NodeBox9
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:window_closed_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction_steel:wall_doorway_steel", {
	description = "Steel Doorway",
	inventory_image = "construction_doorwaysteel.png",
	wield_image = "construction_doorwaysteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox3
			{-1.5, 1.5, -0.125, 1.5, 2.3125, 0.125}, -- NodeBox4
			{-1.5, -0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
		}
	}
})

minetest.register_node("construction_steel:door_closed_steel", {
	description = "Steel Door",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3,},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -1.5, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_steel:door_open_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction_steel:door_open_steel", {
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	drop = "construction_steel:door_closed_steel",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{0.375, -1.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:door_closed_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction_steel:beam_steel", {
	description = "Horizontal Steel Beam",
	inventory_image = "construction_beamsteel.png",
	wield_image = "construction_beamsteel.png",
	tiles = {
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png",
		"default_steel_block.png^construction_beamline.png",
		"default_steel_block.png^construction_beamcross.png",
		"default_steel_block.png^construction_beamcross.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -2.5, 0.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_steel:mech_door_closed_steel", {
	description = "Mechanical Steel Door",
	inventory_image = "construction_mechdoorsteel.png",
	wield_image = "construction_mechdoorsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox3
			{-1.5, -0.5, -0.125, -0.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 1.5, -0.125, 0.5, 2.5, 0.125}, -- NodeBox7
			{-0.5, 1, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
			{-0.5, 0.5, -0.0625, 0.5, 1, 0.0625}, -- NodeBox9
			{-0.5, 0, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox10
			{-0.5, -0.5, -0.0625, 0.5, -2.68221e-007, 0.0625}, -- NodeBox11
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_steel:mech_door_open_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction_steel:mech_door_open_steel", {
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	drop = "construction_steel:mech_door_closed_steel",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, -0.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
			{-0.5, 1.5, -0.125, 0.5, 2.4375, 0.125}, -- NodeBox4
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox6
			{0.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox7
			{-1.4375, 1, -0.0625, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.0625, 1.4375, 1, 0.0625}, -- NodeBox12
			{-1.4375, 0, -0.0625, -0.437499, 0.5, 0.0625}, -- NodeBox13
			{0.4375, -0.5, -0.0625, 1.4375, 1.63913e-007, 0.0625}, -- NodeBox14

		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_steel:mech_door_closed_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction_steel:beam_steel_vertical", {
	description = "Vertical Steel Beam",
	inventory_image = "construction_beamsteel.png",
	wield_image = "construction_beamsteel.png",
	tiles = {
		"default_steel_block.png^construction_beamcross.png",
		"default_steel_block.png^construction_beamcross.png",
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png^[transformFXR90"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 2.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_steel:foundation_steel", {
	description = "Standard Steel Foundation",
	inventory_image = "construction_foundationsteel.png",
	wield_image = "construction_foundationsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -1.5, 1.5, 0.5, 1.5}, -- NodeBox2
		}
	}
})

minetest.register_node("construction_steel:foundation_thin_steel", {
	description = "Steel Adjustment Foundation",
	inventory_image = "construction_adfoundationsteel.png",
	wield_image = "construction_adfoundationsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_steel:window_steel_large", {
	description = "Large Steel Window",
	inventory_image = "construction_window_largesteel.png",
	wield_image = "construction_window_largesteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.125, 1.5, 0, 0.125}, -- NodeBox1
			{-1.5, 0, -0.125, -1, 2.5, 0.125}, -- NodeBox2
			{1, 0, -0.125, 1.5, 2.5, 0.125}, -- NodeBox3
			{-1.5, 2, -0.125, 1.5, 2.5, 0.125}, -- NodeBox4
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
		}
	}
})

minetest.register_node("construction_steel:glass_large", {
	description = "Large Glass Pane",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_glass_detail.png",
		"default_glass_detail.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1, -1, -0.125, 1, 1, 0.125}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_steel:roof_steel", {
	description = "Steel Roof",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.4375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.125, 0.375, -0.5, 0.125, 0.4375, 0.5}, -- NodeBox2
			{-0.5, 0.375, -0.125, 0.5, 0.4375, 0.125}, -- NodeBox3
		}
	}
})

minetest.register_craftitem("construction_steel:steel_plate", {
	description = "Steel Plate",
	inventory_image = "default_steel_block.png",
})
