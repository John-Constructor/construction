-- Code License: CC BY-SA
-- (https://creativecommons.org/licenses/by-sa/3.0/legalcode)

-- Mid Nodes and craftitems

minetest.register_node("construction_tin:wall_tin", {
	description = "Tin Wall",
	inventory_image = "construction_walltin.png",
	wield_image = "construction_walltin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
		}
	}
})

minetest.register_node("construction_tin:window_closed_tin", {
	description = "Tin Window",
	inventory_image = "construction_windowtin.png",
	wield_image = "construction_windowtin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 0.5, -0.0625, 0, 1.5, 0.0625}, -- NodeBox7
			{0, 0.5, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_tin:window_open_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction_tin:window_open_tin", {
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	drop = "construction_tin:window_closed_tin",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5625, 0.5, -0.5, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.5, 0.5625, 1.5, 0.0625}, -- NodeBox9
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_tin:window_closed_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction_tin:wall_doorway_tin", {
	description = "Tin Doorway",
	inventory_image = "construction_doorwaytin.png",
	wield_image = "construction_doorwaytin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox3
			{-1.5, 1.5, -0.125, 1.5, 2.3125, 0.125}, -- NodeBox4
			{-1.5, -0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
		}
	}
})

minetest.register_node("construction_tin:door_closed_tin", {
	description = "Tin Door",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3,},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -1.5, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_tin:door_open_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction_tin:door_open_tin", {
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	drop = "construction_tin:door_closed_tin",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{0.375, -1.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_tin:door_closed_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction_tin:beam_tin", {
	description = "Horizontal Tin Beam",
	inventory_image = "construction_beamtin.png",
	wield_image = "construction_beamtin.png",
	tiles = {
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png",
		"default_tin_block.png^construction_beamline.png",
		"default_tin_block.png^construction_beamcross.png",
		"default_tin_block.png^construction_beamcross.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -2.5, 0.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_tin:mech_door_closed_tin", {
	description = "Mechanical Tin Door",
	inventory_image = "construction_mechdoortin.png",
	wield_image = "construction_mechdoortin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox3
			{-1.5, -0.5, -0.125, -0.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 1.5, -0.125, 0.5, 2.5, 0.125}, -- NodeBox7
			{-0.5, 1, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
			{-0.5, 0.5, -0.0625, 0.5, 1, 0.0625}, -- NodeBox9
			{-0.5, 0, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox10
			{-0.5, -0.5, -0.0625, 0.5, -2.68221e-007, 0.0625}, -- NodeBox11
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_tin:mech_door_open_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction_tin:mech_door_open_tin", {
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	drop = "construction_tin:mech_door_closed_tin",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, -0.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
			{-0.5, 1.5, -0.125, 0.5, 2.4375, 0.125}, -- NodeBox4
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox6
			{0.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox7
			{-1.4375, 1, -0.0625, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.0625, 1.4375, 1, 0.0625}, -- NodeBox12
			{-1.4375, 0, -0.0625, -0.437499, 0.5, 0.0625}, -- NodeBox13
			{0.4375, -0.5, -0.0625, 1.4375, 1.63913e-007, 0.0625}, -- NodeBox14

		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction_tin:mech_door_closed_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction_tin:beam_tin_vertical", {
	description = "Vertical Tin Beam",
	inventory_image = "construction_beamtin.png",
	wield_image = "construction_beamtin.png",
	tiles = {
		"default_tin_block.png^construction_beamcross.png",
		"default_tin_block.png^construction_beamcross.png",
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png^[transformFXR90"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 2.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_tin:foundation_tin", {
	description = "Standard Tin Foundation",
	inventory_image = "construction_foundationtin.png",
	wield_image = "construction_foundationtin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -1.5, 1.5, 0.5, 1.5}, -- NodeBox2
		}
	}
})

minetest.register_node("construction_tin:foundation_thin_tin", {
	description = "Tin Adjustment Foundation",
	inventory_image = "construction_adfoundationtin.png",
	wield_image = "construction_adfoundationtin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction_tin:roof_tin", {
	description = "Tin Roof",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.4375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.125, 0.375, -0.5, 0.125, 0.4375, 0.5}, -- NodeBox2
			{-0.5, 0.375, -0.125, 0.5, 0.4375, 0.125}, -- NodeBox3
		}
	}
})

minetest.register_craftitem("construction_tin:tin_plate", {
	description = "Tin Plate",
	inventory_image = "default_tin_block.png",
})
