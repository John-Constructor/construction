-- Code License: CC BY-SA
-- (https://creativecommons.org/licenses/by-sa/3.0/legalcode)

-- Early Nodes

minetest.register_node("construction:wall_wood", {
	description = "Wooden Wall",
	inventory_image = "construction_wallwood.png",
	wield_image = "construction_wallwood.png",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
		}
	}
})

minetest.register_node("construction:window_closed_wood", {
	description = "Wooden Window",
	inventory_image = "construction_windowwood.png",
	wield_image = "construction_windowwood.png",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 0.5, -0.0625, 0, 1.5, 0.0625}, -- NodeBox7
			{0, 0.5, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:window_open_wood", param2 = node.param2})
                end,
})

minetest.register_node("construction:window_open_wood", {
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	drop = "construction:window_closed_wood",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5625, 0.5, -0.5, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.5, 0.5625, 1.5, 0.0625}, -- NodeBox9
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:window_closed_wood", param2 = node.param2})
                end,
})

minetest.register_node("construction:wall_doorway_wood", {
	description = "Wooden Doorway",
	inventory_image = "construction_doorwaywood.png",
	wield_image = "construction_doorwaywood.png",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox3
			{-1.5, 1.5, -0.125, 1.5, 2.3125, 0.125}, -- NodeBox4
			{-1.5, -0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
		}
	}
})

minetest.register_node("construction:door_closed_wood", {
	description = "Wooden Door",
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -1.5, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:door_open_wood", param2 = node.param2})
                end,
})

minetest.register_node("construction:door_open_wood", {
	tiles = {
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png",
		"default_wood.png"
	},
	drawtype = "nodebox",
	drop = "construction:door_closed_wood",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{0.375, -1.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:door_closed_wood", param2 = node.param2})
                end,
})

minetest.register_node("construction:beam_wood", {
	description = "Horizontal Wooden Beam",
	inventory_image = "construction_beamwood.png",
	wield_image = "construction_beamwood.png",
	tiles = {
		"default_tree.png",
		"default_tree.png",
		"default_tree.png^[transformFXR90",
		"default_tree.png^[transformFXR90",
		"default_tree_top.png",
		"default_tree_top.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -2.5, 0.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction:beam_wood_vertical", {
	description = "Vertical Wooden Beam",
	inventory_image = "construction_beamwood.png",
	wield_image = "construction_beamwood.png",
	tiles = {
		"default_tree_top.png",
		"default_tree_top.png",
		"default_tree.png",
		"default_tree.png",
		"default_tree.png",
		"default_tree.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {choppy = 3, flammable = 1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 2.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction:foundation", {
	description = "Standard Foundation",
	inventory_image = "construction_foundationcobble.png",
	wield_image = "construction_foundationcobble.png",
	tiles = {
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -1.5, 1.5, 0.5, 1.5}, -- NodeBox2
		}
	}
})

minetest.register_node("construction:foundation_thin", {
	description = "Adjustment Foundation",
	inventory_image = "construction_adfoundationcobble.png",
	wield_image = "construction_adfoundationcobble.png",
	tiles = {
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png",
		"default_cobble.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

-- Mid Nodes and craftitems

minetest.register_node("construction:wall_tin", {
	description = "Tin Wall",
	inventory_image = "construction_walltin.png",
	wield_image = "construction_walltin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
		}
	}
})

minetest.register_node("construction:window_closed_tin", {
	description = "Tin Window",
	inventory_image = "construction_windowtin.png",
	wield_image = "construction_windowtin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 0.5, -0.0625, 0, 1.5, 0.0625}, -- NodeBox7
			{0, 0.5, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:window_open_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction:window_open_tin", {
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	drop = "construction:window_closed_tin",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5625, 0.5, -0.5, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.5, 0.5625, 1.5, 0.0625}, -- NodeBox9
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:window_closed_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction:wall_doorway_tin", {
	description = "Tin Doorway",
	inventory_image = "construction_doorwaytin.png",
	wield_image = "construction_doorwaytin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox3
			{-1.5, 1.5, -0.125, 1.5, 2.3125, 0.125}, -- NodeBox4
			{-1.5, -0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
		}
	}
})

minetest.register_node("construction:door_closed_tin", {
	description = "Tin Door",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3,},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -1.5, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:door_open_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction:door_open_tin", {
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	drop = "construction:door_closed_tin",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{0.375, -1.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:door_closed_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction:beam_tin", {
	description = "Horizontal Tin Beam",
	inventory_image = "construction_beamtin.png",
	wield_image = "construction_beamtin.png",
	tiles = {
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png",
		"default_tin_block.png^construction_beamline.png",
		"default_tin_block.png^construction_beamcross.png",
		"default_tin_block.png^construction_beamcross.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -2.5, 0.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction:mech_door_closed_tin", {
	description = "Mechanical Tin Door",
	inventory_image = "construction_mechdoortin.png",
	wield_image = "construction_mechdoortin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox3
			{-1.5, -0.5, -0.125, -0.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 1.5, -0.125, 0.5, 2.5, 0.125}, -- NodeBox7
			{-0.5, 1, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
			{-0.5, 0.5, -0.0625, 0.5, 1, 0.0625}, -- NodeBox9
			{-0.5, 0, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox10
			{-0.5, -0.5, -0.0625, 0.5, -2.68221e-007, 0.0625}, -- NodeBox11
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:mech_door_open_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction:mech_door_open_tin", {
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	drop = "construction:mech_door_closed_tin",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, -0.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
			{-0.5, 1.5, -0.125, 0.5, 2.4375, 0.125}, -- NodeBox4
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox6
			{0.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox7
			{-1.4375, 1, -0.0625, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.0625, 1.4375, 1, 0.0625}, -- NodeBox12
			{-1.4375, 0, -0.0625, -0.437499, 0.5, 0.0625}, -- NodeBox13
			{0.4375, -0.5, -0.0625, 1.4375, 1.63913e-007, 0.0625}, -- NodeBox14

		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:mech_door_closed_tin", param2 = node.param2})
                end,
})

minetest.register_node("construction:beam_tin_vertical", {
	description = "Vertical Tin Beam",
	inventory_image = "construction_beamtin.png",
	wield_image = "construction_beamtin.png",
	tiles = {
		"default_tin_block.png^construction_beamcross.png",
		"default_tin_block.png^construction_beamcross.png",
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png^[transformFXR90",
		"default_tin_block.png^construction_beamline.png^[transformFXR90"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 2.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction:foundation_tin", {
	description = "Standard Tin Foundation",
	inventory_image = "construction_foundationtin.png",
	wield_image = "construction_foundationtin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -1.5, 1.5, 0.5, 1.5}, -- NodeBox2
		}
	}
})

minetest.register_node("construction:foundation_thin_tin", {
	description = "Tin Adjustment Foundation",
	inventory_image = "construction_adfoundationtin.png",
	wield_image = "construction_adfoundationtin.png",
	tiles = {
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png",
		"default_tin_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_craftitem("construction:tin_plate", {
	description = "Tin Plate",
	inventory_image = "default_tin_block.png",
})

minetest.register_node("construction:wall_steel", {
	description = "Steel Wall",
	inventory_image = "construction_wallsteel.png",
	wield_image = "construction_wallsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
		}
	}
})

minetest.register_node("construction:window_closed_steel", {
	description = "Steel Window",
	inventory_image = "construction_windowsteel.png",
	wield_image = "construction_windowsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 0.5, -0.0625, 0, 1.5, 0.0625}, -- NodeBox7
			{0, 0.5, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:window_open_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction:window_open_steel", {
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	drop = "construction:window_closed_steel",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, 1.5, 0.5, 0.125}, -- NodeBox2
			{-1.5, 0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox3
			{0.5, 0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox4
			{-1.5, 1.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5625, 0.5, -0.5, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.5, 0.5625, 1.5, 0.0625}, -- NodeBox9
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:window_closed_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction:wall_doorway_steel", {
	description = "Steel Doorway",
	inventory_image = "construction_doorwaysteel.png",
	wield_image = "construction_doorwaysteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 1.5, 0.125}, -- NodeBox3
			{-1.5, 1.5, -0.125, 1.5, 2.3125, 0.125}, -- NodeBox4
			{-1.5, -0.5, -0.125, -0.5, 1.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
		}
	}
})

minetest.register_node("construction:door_closed_steel", {
	description = "Steel Door",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3,},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -1.5, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:door_open_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction:door_open_steel", {
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	drop = "construction:door_closed_steel",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{0.375, -1.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:door_closed_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction:beam_steel", {
	description = "Horizontal Steel Beam",
	inventory_image = "construction_beamsteel.png",
	wield_image = "construction_beamsteel.png",
	tiles = {
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png",
		"default_steel_block.png^construction_beamline.png",
		"default_steel_block.png^construction_beamcross.png",
		"default_steel_block.png^construction_beamcross.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -2.5, 0.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction:mech_door_closed_steel", {
	description = "Mechanical Steel Door",
	inventory_image = "construction_mechdoorsteel.png",
	wield_image = "construction_mechdoorsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox2
			{0.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox3
			{-1.5, -0.5, -0.125, -0.5, 2.5, 0.125}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
			{-0.5, 1.5, -0.125, 0.5, 2.5, 0.125}, -- NodeBox7
			{-0.5, 1, -0.0625, 0.5, 1.5, 0.0625}, -- NodeBox8
			{-0.5, 0.5, -0.0625, 0.5, 1, 0.0625}, -- NodeBox9
			{-0.5, 0, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox10
			{-0.5, -0.5, -0.0625, 0.5, -2.68221e-007, 0.0625}, -- NodeBox11
		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:mech_door_open_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction:mech_door_open_steel", {
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	drop = "construction:mech_door_closed_steel",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
fixed = {
			{-1.5, -0.5, -0.5, -0.5, -0.3125, 0.5}, -- NodeBox1
			{-1.5, -0.5, -0.125, -0.5, 2.5, 0.125}, -- NodeBox2
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox3
			{-0.5, 1.5, -0.125, 0.5, 2.4375, 0.125}, -- NodeBox4
			{0.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox6
			{0.5, -0.5, -0.125, 1.5, 2.5, 0.125}, -- NodeBox7
			{-1.4375, 1, -0.0625, -0.4375, 1.5, 0.0625}, -- NodeBox8
			{0.4375, 0.5, -0.0625, 1.4375, 1, 0.0625}, -- NodeBox12
			{-1.4375, 0, -0.0625, -0.437499, 0.5, 0.0625}, -- NodeBox13
			{0.4375, -0.5, -0.0625, 1.4375, 1.63913e-007, 0.0625}, -- NodeBox14

		},
	},
                on_rightclick = function(pos, node, puncher)
                    minetest.env:add_node(pos, {name = "construction:mech_door_closed_steel", param2 = node.param2})
                end,
})

minetest.register_node("construction:beam_steel_vertical", {
	description = "Vertical Steel Beam",
	inventory_image = "construction_beamsteel.png",
	wield_image = "construction_beamsteel.png",
	tiles = {
		"default_steel_block.png^construction_beamcross.png",
		"default_steel_block.png^construction_beamcross.png",
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png^[transformFXR90",
		"default_steel_block.png^construction_beamline.png^[transformFXR90"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 2.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction:foundation_steel", {
	description = "Standard Steel Foundation",
	inventory_image = "construction_foundationsteel.png",
	wield_image = "construction_foundationsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -1.5, 1.5, 0.5, 1.5}, -- NodeBox2
		}
	}
})

minetest.register_node("construction:foundation_thin_steel", {
	description = "Steel Adjustment Foundation",
	inventory_image = "construction_adfoundationsteel.png",
	wield_image = "construction_adfoundationsteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.5, 1.5, 0.5, 0.5}, -- NodeBox1
		}
	}
})

minetest.register_node("construction:window_steel_large", {
	description = "Large Steel Window",
	inventory_image = "construction_window_largesteel.png",
	wield_image = "construction_window_largesteel.png",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1.5, -0.5, -0.125, 1.5, 0, 0.125}, -- NodeBox1
			{-1.5, 0, -0.125, -1, 2.5, 0.125}, -- NodeBox2
			{1, 0, -0.125, 1.5, 2.5, 0.125}, -- NodeBox3
			{-1.5, 2, -0.125, 1.5, 2.5, 0.125}, -- NodeBox4
			{-1.5, -0.5, -0.5, 1.5, -0.3125, 0.5}, -- NodeBox5
			{-1.5, 2.3125, -0.5, 1.5, 2.5, 0.5}, -- NodeBox6
		}
	}
})

minetest.register_node("construction:glass_large", {
	description = "Large Glass Pane",
	tiles = {
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_steel_block.png",
		"default_glass_detail.png",
		"default_glass_detail.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky = 3},
	node_box = {
		type = "fixed",
		fixed = {
			{-1, -1, -0.125, 1, 1, 0.125}, -- NodeBox1
		}
	}
})

minetest.register_craftitem("construction:steel_plate", {
	description = "Steel Plate",
	inventory_image = "default_steel_block.png",
})

-- Early Crafts
minetest.register_craft({
	output = 'construction:wall_wood 3',
	recipe = {
		{'default:wood', 'default:wood', 'default:wood'},
		{'default:wood', 'default:wood', 'default:wood'},
		{'default:wood', 'default:wood', 'default:wood'},
	}
})

minetest.register_craft({
	output = 'construction:wall_doorway_wood 3',
	recipe = {
		{'default:wood', 'default:wood', 'default:wood'},
		{'default:wood', '', 'default:wood'},
		{'default:wood', '', 'default:wood'},
	}
})

minetest.register_craft({
	output = 'construction:beam_wood',
	recipe = {
		{'', 'default:stick', ''},
		{'default:tree', 'default:tree', 'default:tree'},
		{'', 'default:stick', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_wood_vertical',
	recipe = {
		{'', 'default:tree', ''},
		{'default:stick', 'default:tree', 'default:stick'},
		{'', 'default:tree', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_wood_vertical',
	recipe = {
		{'', '', ''},
		{'', 'construction:beam_wood', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_wood',
	recipe = {
		{'', '', ''},
		{'', 'construction:beam_wood_vertical', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:foundation',
	recipe = {
		{'default:cobble', 'default:cobble', 'default:cobble'},
		{'default:cobble', 'default:cobble', 'default:cobble'},
		{'default:cobble', 'default:cobble', 'default:cobble'},
	}
})

minetest.register_craft({
	output = 'construction:foundation_thin 3',
	recipe = {
		{'', '', ''},
		{'', 'construction:foundation', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:foundation',
	recipe = {
		{'', '', ''},
		{'construction:foundation_thin', 'construction:foundation_thin', 'construction:foundation_thin'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'default:cobble 3',
	recipe = {
		{'', '', ''},
		{'', 'construction:foundation_thin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:window_closed_wood',
	recipe = {
		{'', '', ''},
		{'', 'construction:wall_wood', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:door_closed_wood',
	recipe = {
		{'', '', ''},
		{'', 'doors:door_wood', ''},
		{'', '', ''},
	}
})

-- Mid Crafts


minetest.register_craft({
	output = 'construction:wall_tin',
	recipe = {
		{'construction:tin_plate', 'construction:tin_plate', 'construction:tin_plate'},
		{'construction:tin_plate', 'construction:tin_plate', 'construction:tin_plate'},
		{'construction:tin_plate', 'construction:tin_plate', 'construction:tin_plate'},
	}
})

minetest.register_craft({
	output = 'construction:wall_doorway_tin',
	recipe = {
		{'construction:tin_plate', 'construction:tin_plate', 'construction:tin_plate'},
		{'construction:tin_plate', '', 'construction:tin_plate'},
		{'construction:tin_plate', '', 'construction:tin_plate'},
	}
})

minetest.register_craft({
	output = 'construction:beam_tin',
	recipe = {
		{'', 'construction:tin_plate', ''},
		{'default:tin_ingot', 'default:tin_ingot', 'default:tin_ingot'},
		{'', 'construction:tin_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_tin_vertical',
	recipe = {
		{'', 'default:tin_ingot', ''},
		{'construction:tin_plate', 'default:tin_ingot', 'construction:tin_plate'},
		{'', 'default:tin_ingot', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_tin_vertical',
	recipe = {
		{'', '', ''},
		{'', 'construction:beam_tin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_tin',
	recipe = {
		{'', '', ''},
		{'', 'construction:beam_tin_vertical', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:foundation_tin',
	recipe = {
		{'construction:tin_plate', 'construction:tin_plate', 'construction:tin_plate'},
		{'construction:tin_plate', 'default:tinblock', 'construction:tin_plate'},
		{'construction:tin_plate', 'construction:tin_plate', 'construction:tin_plate'},
	}
})

minetest.register_craft({
	output = 'construction:foundation_thin_tin 3',
	recipe = {
		{'', '', ''},
		{'', 'construction:foundation_tin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:foundation_thin_tin 2',
	recipe = {
		{'', 'construction:tin_plate', ''},
		{'', 'default:tinblock', ''},
		{'', 'construction:tin_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction:foundation_tin',
	recipe = {
		{'', '', ''},
		{'construction:foundation_thin_tin', 'construction:foundation_thin_tin', 'construction:foundation_thin_tin'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:tin_plate 15',
	recipe = {
		{'', '', ''},
		{'', 'construction:foundation_thin_tin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:tin_plate 9',
	recipe = {
		{'', '', ''},
		{'default:tin_ingot', 'default:tin_ingot', 'default:tin_ingot'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:window_closed_tin',
	recipe = {
		{'', '', ''},
		{'', 'construction:wall_tin', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:door_closed_tin',
	recipe = {
		{'', '', ''},
		{'', 'construction:tin_plate', ''},
		{'', 'construction:tin_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction:mech_door_closed_tin',
	recipe = {
		{'', 'construction:wall_doorway_tin', ''},
		{'', 'construction:tin_plate', ''},
		{'', 'construction:tin_plate', ''},
	}
})

--Steel

minetest.register_craft({
	output = 'construction:wall_steel',
	recipe = {
		{'construction:steel_plate', 'construction:steel_plate', 'construction:steel_plate'},
		{'construction:steel_plate', 'construction:steel_plate', 'construction:steel_plate'},
		{'construction:steel_plate', 'construction:steel_plate', 'construction:steel_plate'},
	}
})

minetest.register_craft({
	output = 'construction:wall_doorway_steel',
	recipe = {
		{'construction:steel_plate', 'construction:steel_plate', 'construction:steel_plate'},
		{'construction:steel_plate', '', 'construction:steel_plate'},
		{'construction:steel_plate', '', 'construction:steel_plate'},
	}
})

minetest.register_craft({
	output = 'construction:beam_steel',
	recipe = {
		{'', 'construction:steel_plate', ''},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'', 'construction:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_steel_vertical',
	recipe = {
		{'', 'default:steel_ingot', ''},
		{'construction:steel_plate', 'default:steel_ingot', 'construction:steel_plate'},
		{'', 'default:steel_ingot', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_steel_vertical',
	recipe = {
		{'', '', ''},
		{'', 'construction:beam_steel', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:beam_steel',
	recipe = {
		{'', '', ''},
		{'', 'construction:beam_steel_vertical', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:foundation_steel',
	recipe = {
		{'construction:steel_plate', 'construction:steel_plate', 'construction:steel_plate'},
		{'construction:steel_plate', 'default:steelblock', 'construction:steel_plate'},
		{'construction:steel_plate', 'construction:steel_plate', 'construction:steel_plate'},
	}
})

minetest.register_craft({
	output = 'construction:foundation_thin_steel 3',
	recipe = {
		{'', '', ''},
		{'', 'construction:foundation_steel', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:foundation_thin_steel 2',
	recipe = {
		{'', 'construction:steel_plate', ''},
		{'', 'default:steelblock', ''},
		{'', 'construction:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction:foundation_steel',
	recipe = {
		{'', '', ''},
		{'construction:foundation_thin_steel', 'construction:foundation_thin_steel', 'construction:foundation_thin_steel'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:steel_plate 15',
	recipe = {
		{'', '', ''},
		{'', 'construction:foundation_thin_steel', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:steel_plate 9',
	recipe = {
		{'', '', ''},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:window_closed_steel',
	recipe = {
		{'', '', ''},
		{'', 'construction:wall_steel', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'construction:door_closed_steel',
	recipe = {
		{'', '', ''},
		{'', 'construction:steel_plate', ''},
		{'', 'construction:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction:mech_door_closed_steel',
	recipe = {
		{'', 'construction:wall_doorway_steel', ''},
		{'', 'construction:steel_plate', ''},
		{'', 'construction:steel_plate', ''},
	}
})

minetest.register_craft({
	output = 'construction:window_steel_large',
	recipe = {
		{'construction:steel_plate', 'construction:steel_plate', 'construction:steel_plate'},
		{'construction:steel_plate', '', 'construction:steel_plate'},
		{'construction:steel_plate', 'construction:steel_plate', 'construction:steel_plate'},
	}
})

minetest.register_craft({
	output = 'construction:glass_large 2',
	recipe = {
		{'', 'construction:steel_plate', ''},
		{'construction:steel_plate', 'default:glass', 'construction:steel_plate'},
		{'', 'construction:steel_plate', ''},
	}
})


